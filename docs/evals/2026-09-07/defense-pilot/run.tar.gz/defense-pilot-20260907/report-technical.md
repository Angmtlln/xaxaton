# Проверка агента для защиты

Версия: defense-1. Commit: `0712023b10c75bce4ee174a3035c63c75c9e2ce7`. Модель: `z-ai/glm-5.3-flash`.
Набор: 20 сценариев, 20 попыток, 27 оцениваемых реплик.
Полностью выполнено: **0/20 (0.0%)**.
Остальные статусы: `{'NOT_REVIEWED': 20}`. Обязательные части выполнены: 0/41.

**Это предварительная автоматическая оценка, не человеческая приёмка.** NOT_REVIEWED, UNCERTAIN и незавершённые попытки не засчитываются в PASS.
Один диалог — один сценарий. Повторы считаются попытками; их нельзя выдавать за новые независимые вопросы.
Техническое выполнение и смысл оцениваются отдельно. Latency не превращает правильный ответ в смысловой FAIL.
Данные: изолированная PostgreSQL, неизменные 100 карточек; web=disabled. Это runtime eval, не HTTP/MCP/UI приёмка.
Latency по всем scored-репликам, включая ошибки: {'p50': 8649, 'p95': 42313}. Цена в долларах не рассчитана; фактические токены ниже.

| Категория | Статусы |
|---|---|
| G | {'NOT_REVIEWED': 2} |
| F | {'NOT_REVIEWED': 2} |
| L | {'NOT_REVIEWED': 2} |
| N | {'NOT_REVIEWED': 2} |
| R | {'NOT_REVIEWED': 2} |
| S | {'NOT_REVIEWED': 2} |
| E | {'NOT_REVIEWED': 2} |
| C | {'NOT_REVIEWED': 3} |
| M | {'NOT_REVIEWED': 3} |

| Модель / этап | Вызовы | Входные токены | Выходные токены |
|---|---:|---:|---:|
| domain:openai/gpt-oss-20b | 16 | 15589 | 3108 |
| domain:openai/gpt-oss-120b | 10 | 17158 | 2405 |
| domain:qwen/qwen3.8-27b | 8 | 5266 | 1167 |
| master:z-ai/glm-5.3-flash | 50 | 603500 | 21903 |

| Сценарий | Попытка | Статус | Технические ошибки |
|---|---:|---|---|
| G01 | 1 | NOT_REVIEWED |  |
| G03 | 1 | NOT_REVIEWED |  |
| F01 | 1 | NOT_REVIEWED |  |
| F03 | 1 | NOT_REVIEWED |  |
| L01 | 1 | NOT_REVIEWED |  |
| L03 | 1 | NOT_REVIEWED |  |
| N01 | 1 | NOT_REVIEWED |  |
| N03 | 1 | NOT_REVIEWED |  |
| R01 | 1 | NOT_REVIEWED |  |
| R03 | 1 | NOT_REVIEWED |  |
| S01 | 1 | NOT_REVIEWED |  |
| S03 | 1 | NOT_REVIEWED |  |
| E01 | 1 | NOT_REVIEWED |  |
| E03 | 1 | NOT_REVIEWED |  |
| C01 | 1 | NOT_REVIEWED |  |
| C02 | 1 | NOT_REVIEWED |  |
| C03 | 1 | NOT_REVIEWED |  |
| M01 | 1 | NOT_REVIEWED |  |
| M03 | 1 | NOT_REVIEWED |  |
| M07 | 1 | NOT_REVIEWED |  |
